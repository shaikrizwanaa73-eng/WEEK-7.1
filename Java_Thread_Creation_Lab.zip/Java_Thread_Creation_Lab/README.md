# Java Thread Creation Lab (1.1)

## Aim
Create three concurrent threads that print:
- `Good Morning` every 1 second
- `Hello` every 2 seconds
- `Welcome` every 3 seconds

The program is implemented using both `Thread` and `Runnable`.

## Files
- `ThreadClassDemo.java` — extends the `Thread` class.
- `RunnableDemo.java` — implements the `Runnable` interface.

## How to compile and run
Make sure Java JDK is installed. Open Terminal in this folder.

### Method 1: Thread class
```bash
javac ThreadClassDemo.java
java ThreadClassDemo
```

### Method 2: Runnable interface
```bash
javac RunnableDemo.java
java RunnableDemo
```

Stop either program with `Ctrl+C` because the threads run indefinitely.

## Note
Output order may vary because the threads execute concurrently. The messages will continue until the program is stopped.
